#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas
from pandas.plotting import scatter_matrix
import matplotlib.pyplot as plt
from sklearn import model_selection
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC


# In[3]:


url = "C:/Users/Akhil Jalla/Desktop/Final Project/Final_part1.csv"
names = ['ROI', 'Foreground Blur Score', 'Background blur score', 'Brightness Score', 'Noise score', 'Simplicity score', 'Contrast score','Area Ratio','Rule of third score','Potrait mode','Landscape Mode','Output']
dataset = pandas.read_csv(url, skiprows=1, names=names)


# In[4]:


# shape
print(dataset.shape)


# In[5]:


print(dataset.head(20))


# In[6]:


print(dataset.describe())


# In[7]:


print(dataset.groupby('Output').size())


# In[8]:


dataset.hist()
plt.show()


# In[9]:


scatter_matrix(dataset)
plt.show()


# In[11]:


import numpy as np


# In[21]:


Y = np.array(dataset['Output'])
X= dataset.drop('Output', axis = 1)
feature_list = list(X.columns)
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.8
                                                    ,random_state = 0, shuffle=True)


# In[22]:


from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier()
model.fit(X_train, Y_train)


# In[23]:


models = []
models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC(gamma='auto')))


# In[24]:


score = model.score(X_test, Y_test)
print(score)


# In[25]:


prediction = model.predict(X_test)
# prediction = model.predict([[0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1]])
print(prediction)


# In[26]:


print(X.head(10))


# In[27]:


print(Y[0:13])


# In[17]:


y = model.feature_importances_


# In[28]:


fig, ax = plt.subplots() 
width = 0.4 # the width of the bars 
ind = np.arange(len(y)) # the x locations for the groups
ax.barh(ind, y, width, color='green')
ax.set_yticks(ind+width/10)
ax.set_yticklabels(feature_list, minor=False)
plt.title('Feature importance in RandomForest Classifier')
plt.xlabel('Relative importance')
plt.ylabel('feature') 
plt.figure(figsize=(5,5))
fig.set_size_inches(6.5, 4.5, forward=True)


# In[1]:


from pexels_api import API


# In[ ]:




