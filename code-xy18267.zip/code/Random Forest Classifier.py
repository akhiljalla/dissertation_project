#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
url = "C:/Users/Akhil Jalla/Desktop/Final Project/Final_part1.csv"
names = ['ROI', 'Foreground Blur Score', 'Background blur score', 'Brightness Score', 'Noise score', 'Simplicity score', 'Contrast score','Area Ratio','Rule of third score','Potrait mode','Landscape Mode','Output']
features = pd.read_csv(url, skiprows=1, names=names)


# In[2]:


print(features.head(5))


# In[3]:


print(features.shape)


# In[4]:


print(features.describe())


# In[ ]:





# In[5]:


import numpy as np


# In[6]:


labels = np.array(features['Output'])


# In[7]:


print(labels)


# In[8]:


features= features.drop('Output', axis = 1)


# In[9]:


print(features.columns)


# In[10]:


feature_list = list(features.columns)


# In[11]:


features1 = np.array(features)


# In[12]:


from sklearn.model_selection import train_test_split


# In[13]:


train_features, test_features, train_labels, test_labels = train_test_split(features, labels, test_size = 0.20, random_state = 42)


# In[14]:


print('Training Features Shape:', train_features.shape)
print('Training Labels Shape:', train_labels.shape)
print('Testing Features Shape:', test_features.shape)
print('Testing Labels Shape:', test_labels.shape)


# In[33]:



from sklearn.ensemble import RandomForestRegressor

from sklearn.ensemble import RandomForestClassifier

#Create a Gaussian Classifier
clf=RandomForestClassifier(n_estimators=10)

#Train the model using the training sets y_pred=clf.predict(X_test)
clf.fit(train_features,train_labels)

y_pred=clf.predict(test_features)


# In[34]:


print(clf.score(test_features,test_labels))


# In[35]:


from sklearn import metrics

feature_imp = pd.Series(clf.feature_importances_,index=feature_list).sort_values(ascending=False)

print(feature_imp)


# In[36]:


for feature in zip(feature_list, clf.feature_importances_):
    print(feature)


# In[37]:


from sklearn.metrics import log_loss
# clf_probs = clf.predict_proba(test_features)
# score = log_loss(test_labels, clf_probs)
# print(score)
# probs = clf.predict_proba(test_features)
# keep the predictions for class 1 only
# probs = probs[:, 1]
# # calculate log loss
# loss = log_loss(test_labels, probs)
# print(loss)
y_pred_prob = clf.predict_proba(test_features)[:, 1]
# from sklearn.preprocessing import binarize
# y_pred_class = binarize(y_pred_prob, 0.3)[0]
# loss = log_loss(y_pred_class, y_pred_prob)
# print(loss)
from sklearn.metrics import cohen_kappa_score
yhat_classes = clf.predict(test_features)
kappa = cohen_kappa_score(test_labels, yhat_classes)
print('Cohens kappa: %f' % kappa)
# auc = roc_auc_score(test_labels, yhat_classes)
# print('ROC AUC: %f' % auc)
# from sklearn.metrics import matthews_corrcoef
# print(matthews_corrcoef(test_labels, yhat_classes))
from sklearn.metrics import brier_score_loss
y_preds = clf.predict_proba(test_features)
preds = y_preds[:,1]
clf_score = brier_score_loss(test_labels, preds, pos_label=1)
print(clf_score)


# In[38]:


import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')
# Creating a bar plot
sns.barplot(x=feature_imp, y=feature_imp.index)
# Add labels to your graph
plt.xlabel('Feature Importance Score')
plt.ylabel('Features')
plt.title("Visualizing Important Features")
plt.legend()
plt.show()


# In[45]:


from sklearn import metrics
print(metrics.accuracy_score(test_labels, y_pred))

def f1 (precision, recall):
    return  2 * ((precision * recall)/ (precision + recall))

print("Accuracy:",metrics.accuracy_score(test_labels, y_pred))
print("Precision:",metrics.precision_score(test_labels, y_pred))
print("Recall:",metrics.recall_score(test_labels, y_pred))
print("F1 score:",f1(metrics.precision_score(test_labels, y_pred),metrics.recall_score(test_labels, y_pred)))


# In[43]:


from sklearn.model_selection import cross_val_score
from sklearn.metrics import classification_report, confusion_matrix

conf_mat = confusion_matrix(test_labels, y_pred)
print(conf_mat)
import seaborn
seaborn.heatmap(conf_mat)
plt.show()


# In[44]:


#get correlations of each features in dataset
corrmat = features.corr()
top_corr_features = corrmat.index
plt.figure(figsize=(20,20))
#plot heat map
plt.figure(figsize = (16,8))
g=sns.heatmap(features[top_corr_features].corr(),annot=True,cmap="RdYlGn",linewidths=-1.0)
plt.show()


# In[46]:


from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
def plot_roc_curve(fpr, tpr):
    plt.plot(fpr, tpr, color='orange', label='ROC')
    plt.plot([0, 1], [0, 1], color='black', linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve')
    plt.legend()
    plt.show()
    
probs = clf.predict_proba(test_features)
probs = probs[:, 1]
auc = roc_auc_score(test_labels, probs)
print(auc)


# In[47]:


fpr, tpr, thresholds = roc_curve(test_labels, probs)
plot_roc_curve(fpr, tpr)


# In[97]:


from sklearn.tree import DecisionTreeClassifier
clf1 = DecisionTreeClassifier()

clf1 = clf1.fit(train_features,train_labels)


# In[98]:


y_pred = clf1.predict(test_features)


# In[99]:


print(clf1.score(test_features,test_labels))


# In[111]:


from sklearn.tree import export_graphviz
import os
estimator = clf.estimators_[1]
export_graphviz(estimator,out_file='tree.dot',feature_names = features.columns,class_names = 'Output',
                rounded = True, proportion = False, 
                precision = 2, filled = True)
os.system('dot -Tpng tree.dot -o tree.png')


# In[ ]:




